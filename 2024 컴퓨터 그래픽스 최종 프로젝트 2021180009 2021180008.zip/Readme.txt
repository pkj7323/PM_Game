resources파일 압축을 풀어서 resources폴더 통 채로 Release 폴더 안에 넣어주세요

오픈 지엘 파일들이 컴퓨터에 내장되어 있어야 합니다

경로는 이렇게 됩니다
gl 디렉토리 안에 glm디렉토리가 있는 형식 입니다.

#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h> 
#include <gl/glm/glm.hpp>
#include <gl/glm/ext.hpp>
#include <gl/glm/gtc/matrix_transform.hpp>

exe파일을 실행시키면 실행됩니다.

wasd: 앞뒤양옆
R: 일시 무적 + 속도증가 배럴롤
마우스 모션: 화면 회전
마우스 클릭: 레이저 발사

생명력: 11대 맞으면 죽습니다.
포인트: 운석 1개 포인트 1

운석 생성 속도가 점점 빨라집니다.